package set1;
public class Set1 {
	public static void main(String[] args) {
		Country c = new Country();
		c.saveCountryName("India");
		c.saveCountryName("USA");
		c.saveCountryName("England");
		c.saveCountryName("Pakistan");
		
		System.out.println("India : " +c.getCountry("India"));
		System.out.println("China : " +c.getCountry("China"));
	}
}