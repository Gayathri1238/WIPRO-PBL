import java.util.*;
public class Set2 {
	public static void main(String[] args) {
		HashSet<String> h = new HashSet<String>();
		h.add("Sowji");
		h.add("Karthika");
		h.add("Navya");
		h.add("Latha");
		h.add("Harsha");
		
		Iterator<String> it = h.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
		