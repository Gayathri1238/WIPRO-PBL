import java.util.*;
public class Set3 {
	public static void main(String[] args) {
		TreeSet<String> t = new TreeSet<>(Collections.reverseOrder());
		t.add("Sowji");
		t.add("karthika");
		t.add("Navya");
		t.add("Latha");
		t.add("Harshu");

		Iterator<String> it = t.iterator();
		String query = "priya";
		boolean result = false;
		
		while (it.hasNext()) {
			if (it.next().equals(query)) {
				result = true;
				break;
			}
		}
		
		if (result) System.out.println(query + " exists");
		else System.out.println(query + " doesn't exist");

	}

}