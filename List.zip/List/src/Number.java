import java.util.*;
class MyArrayList<E> extends ArrayList<E> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public boolean add(E e) {
		if (e instanceof Integer || e instanceof Float || e instanceof Double) {
			super.add(e);
			return true;
		} else {
			throw new ClassCastException("Only Integer, Float, and Double are supported.");
		}
	}
}

public class Number {

	public static void main(String[] args) {
		List<Object> list = new MyArrayList<>();
		
		try {
			list.add(38);
			list.add(3.142);
			list.add(6.45789);
			list.add("This is String data type");
		} catch (Exception e) {
			System.out.println("Exception occured "+e);
		}
		
		System.out.println(list);

	}

}
