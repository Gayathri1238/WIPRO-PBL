package Employee;
public class Main {
	public static void main(String[] args) {
		EmployeeOperations empDb = new EmployeeOperations();
		
		Employee emp1 = new Employee(101, "Bob", "bob@w3epic.com", "Male", 25000);
		Employee emp2 = new Employee(102, "Alice", "alice@w3epic.com", "Female", 30000);
		Employee emp3 = new Employee(103, "John", "john@w3epic.com","Male", 20000);
		Employee emp4 = new Employee(104, "Ram", "ram@w3epic.com", "Male", 50000);
		
		empDb.addEmployee(emp1);
		empDb.addEmployee(emp2);
		empDb.addEmployee(emp3);
		empDb.addEmployee(emp4);

		for (Employee emp : empDb.listAll())
			emp.GetEmployeeDetails();
		
		System.out.println();
		empDb.deleteEmployee(102);
		
		for (Employee emp : empDb.listAll())
			emp.GetEmployeeDetails();
		
		System.out.println();
		
		System.out.println(empDb.showPaySlip(103));
	}


}
