package Employee;
public class Employee {
	private int empId; 
	private String empName;
	private String email; 
	private String gender;
	private float salary;
	
	public Employee() {}

	public Employee(int empId, String empName, String email, String gender, float salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.email = email;
		this.gender = gender;
		this.salary = salary;
	}

	public void GetEmployeeDetails() {
		System.out.println("Employee Details: EmpId=" + empId + ", EmpName=" + empName + ", EmpEmail=" + email 
				+ ", EmpGender=" + gender + ", EmpSalary=" + salary);
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpEmail() {
		return email;
	}

	public void setEmpEmail(String email) {
		this.email = email;
	}

	public String getEmpGender() {
		return gender;
	}

	public void setEmpGender(String gender) {
		this.gender = gender;
	}

	public float getEmpSalary() {
		return salary;
	}

	public void setEmpSalary(float salary) {
		this.salary = salary;
	}
	
	
}
