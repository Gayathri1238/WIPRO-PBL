import java.util.*;
class Employee {
	private int id;
	private String name;
	private String address;
	private Double salary;
	
	public Employee(int id, String name, String address, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}	
	
	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Employee : id= " + id + ", name= " + name + ", address= " + address + ", salary= " + salary ;
	}
}
public class EmployeeUsingVector {

	public static void main(String[] args) {
		Vector<Employee> list = new Vector<>();
		
		list.add(new Employee(101, "Sowji", "2nd street, India", 230012.0));
		list.add(new Employee(102, "Srinath", "5th street, India", 343200.0));
		list.add(new Employee(103, "Dhana", "12th street, India", 265050.0));
		list.add(new Employee(104, "zinn", "4th street, India", 230023.0));
		
		Iterator<Employee> it = list.iterator();
		while (it.hasNext()) 
			System.out.println(it.next());
		

	}
}
