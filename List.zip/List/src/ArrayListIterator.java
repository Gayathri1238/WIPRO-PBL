import java.util.*;
public class ArrayListIterator {
	public static void main(String[] args) {
		ArrayList<String> monthNames=new ArrayList<>();
		monthNames.add("January");
		monthNames.add("February");
		monthNames.add("March");
		monthNames.add("April");
		monthNames.add("May");
		monthNames.add("June");
		monthNames.add("July");
		monthNames.add("August");
		monthNames.add("September");
		monthNames.add("October");
		monthNames.add("November");
		monthNames.add("December");
		Iterator itr=monthNames.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
