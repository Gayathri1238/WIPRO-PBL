
public class CheckPrimeCmdLine {
	public static void main(String[] args) {
		if(args.length>0) {
			boolean flag=false;
			for(int i=2;i<=Integer.parseInt(args[0])/2;i++) {
				if(Integer.parseInt(args[0])%i==0) {
					flag=true;
					break;
				}
			}
			if(Integer.parseInt(args[0])==1) {
				System.out.println("1 is neither prime nor composite");
			}
			else if(Integer.parseInt(args[0])==0) {
				System.out.println("0 is neither prime nor composite");
			}
			else {
				if (flag==true) {
					System.out.println(args[0]+" is not a prime number");
				}
				else
					System.out.println(args[0]+" is a prime number");
			}
		}
		else {
			System.out.println("please enter an integer number");
		}
	}
}
