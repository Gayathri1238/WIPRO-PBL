
public class FloydWhile {
	public static void main(String[] args) {
		if(args.length>0) {
		int i=0,j=0;
		int n=Integer.parseInt(args[0]);
		while(i<n) {
			j=0;
			while(j<=i) {
				System.out.print("* ");
				j++;
			}
			System.out.println();
			i++;
		}
	}
		else
			System.out.println("Please enter an integer number");
}
}
