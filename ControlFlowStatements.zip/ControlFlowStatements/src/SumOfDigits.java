
import java.util.*;
public class SumOfDigits {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		sc.close();
		String s=Integer.toString(n);
		int r=0,sum=0;
		for(int i=0;i<s.length();i++) {
			r=n%10;
			sum+=r;
			n=n/10;
		}
		System.out.println(sum);
	}
}
