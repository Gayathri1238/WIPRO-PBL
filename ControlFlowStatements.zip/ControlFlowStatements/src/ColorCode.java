
import java.util.*;
public class ColorCode {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the color code:");
		char ch=sc.next().charAt(0);
		sc.close();
		switch(ch) {
		case 'R': System.out.println("The color is Red");
				  break;
		case 'B': System.out.println("The color is Blue");
		  break;
		case 'G':System.out.println("The color is Green");
		  break;
		case 'O':System.out.println("The color is Orange");
		  break;
		case 'Y':System.out.println("The color is Yellow");
		  break;
		case 'W':System.out.println("The color is White");
		  break;
		 default:System.out.println("Invalid code");
		}
	}
}
