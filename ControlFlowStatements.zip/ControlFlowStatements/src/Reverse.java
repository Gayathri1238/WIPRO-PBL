
import java.util.*;
public class Reverse {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		int r=0,s=0;
		while(n!=0) {
			r=n%10;
			s=s*10+r;
			n=n/10;
		}
		System.out.println(s);
	}
}
