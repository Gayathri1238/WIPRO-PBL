package First;
import testPackage.Foundation;
public class AccessControl {
	public static void main(String[] args) {
		Foundation foundation = new Foundation();

		foundation.var4 = 26;
		
		System.out.println(foundation.var4);
	}

}