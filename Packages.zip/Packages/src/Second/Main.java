package Second;

public class Main {
	public static void main(String[] args) {
		Compartment compartment = new Compartment(5.5,3.8,12.6);
		
		System.out.println(compartment);
	}

}
