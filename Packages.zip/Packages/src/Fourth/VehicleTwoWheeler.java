package Fourth;

import com.automobile.Ford;
import com.automobile.Logan;

public class VehicleTwoWheeler {
	public static void main(String[] args) {
	Logan logan = new Logan("Logan XYZ", "TS122122", "Sherlock", 220, 1);
	logan.getModelName();
	logan.getOwnerName();
	logan.getRegistrationNumber();
	logan.speed();
	System.out.println("Has GPS? " + logan.gps());
	
	System.out.println();
	
	Ford ford = new Ford("Mustang GT", "AP161345", "Alice", 200, 1);
	ford.getModelName();
	ford.getOwnerName();
	ford.getRegistrationNumber();
	ford.speed();
	System.out.println("Has AC? " + ford.tempControl());
}
}