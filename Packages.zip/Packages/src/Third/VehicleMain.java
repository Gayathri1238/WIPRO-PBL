package Third;

import com.automobile.Honda;
import com.automobile.twoWheeler.Hero;

	class VehicleMain {

		public static void main(String[] args) {
			Hero hero = new Hero("Glamour 125", "AP091234", "qwerti", 85);
			hero.getModelName();
			hero.getOwnerName();
			hero.getRegistrationNumber();
			hero.getSpeed();
			hero.radio();
			
			System.out.println();
			
			Honda honda = new Honda("Honda City", "AP357777", "abcwert", 110);
			honda.getModelName();
			honda.getOwnerName();
			honda.getRegistrationNumber();
			honda.getSpeed();
			honda.cdplayer();

		}

	}


