package CustomException1;
import java.util.Scanner;

class UserRegistration
{
	@SuppressWarnings({ "resource", "unused" })
	public static void main(String args[])
	{
	
	Scanner input=new Scanner(System.in);
	String name,country;
	name=input.nextLine();
	country=input.nextLine();
	if(country.equals("India")||country.equals("india"))
	{
		System.out.print("User registration done successfully");
	}
	else
	{
		try{
			throw new InvalidCountryException("user outside India cannot beregistered");
			}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

	}
}