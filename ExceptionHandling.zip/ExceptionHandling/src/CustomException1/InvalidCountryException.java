package CustomException1;

@SuppressWarnings("serial")
public class InvalidCountryException extends Exception {
	String d;
	InvalidCountryException(String a)
	{
		d=a;
	}
public String toString()
{
	return(d);
}
}