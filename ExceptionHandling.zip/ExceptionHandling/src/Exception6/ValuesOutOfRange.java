package Exception6;

@SuppressWarnings("serial")
public class ValuesOutOfRange extends Exception {
	public ValuesOutOfRange() {
		super();
		System.out.println("ValuesOutOfRangeException occured");
	}
}
