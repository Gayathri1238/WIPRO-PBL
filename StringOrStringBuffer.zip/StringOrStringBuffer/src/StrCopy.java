import java.util.*;
public class StrCopy {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		int n=sc.nextInt();
		sc.close();
		String s2="";
		s2=s2+s.charAt(0)+s.charAt(1);
		s="";
		for(int i=1;i<=n/2;i++) {
			s+=s2;
		}
		System.out.println(s);
	}
}
