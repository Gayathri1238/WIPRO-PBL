import java.util.*;
public class StringPattern {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();String s1="",s2="",s3="";
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='*') {
				s1=s.replace(Character.toString(s.charAt(i-1)),"");
				s2=s1.replace(Character.toString(s.charAt(i)),"");
				s3=s2.replace(Character.toString(s.charAt(i+1)),"");
			}
		}
		System.out.println(s3);
	}
}
