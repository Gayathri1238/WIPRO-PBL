import java.util.*;
public class Combination {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		sc.close();
		String[] s1=s.split(",");
		StringBuilder sb=new StringBuilder();
		 for (int i = 0; i < s1[0].length() || i < s1[1].length(); i++) { 
			 if (i < s1[0].length()) 
	                sb.append(s1[0].charAt(i));
			 if (i < s1[1].length()) 
	                sb.append(s1[1].charAt(i));
		 }
		 System.out.println(sb.toString());
	}
}
