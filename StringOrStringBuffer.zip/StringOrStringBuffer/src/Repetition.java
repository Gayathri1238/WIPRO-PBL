import java.util.*;
public class Repetition {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		int n=sc.nextInt();
		sc.close();
		int size=s.length()-n;
		String s1="";
		for(int i=0;i<n;i++) {
			s1+=s.substring(size);
		}
		System.out.println(s1);
	}
}
