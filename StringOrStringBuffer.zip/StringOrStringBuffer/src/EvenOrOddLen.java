import java.util.*;
public class EvenOrOddLen {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		sc.close();
		String s2=null;
		int l=s.length();
		if(l%2==0) {
			s2="";
			for(int i=0;i<l/2;i++) {
				s2+=s.charAt(i);
			}
		}
		System.out.println(s2);
	}
}
