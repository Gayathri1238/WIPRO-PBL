import java.util.*;
public class Palindrome {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		sc.close();
		StringBuffer sb=new StringBuffer(s);
		String s2=sb.reverse().toString();
		if(s2.equals(s)) {
			System.out.println("Palindrome");
		}
		else
			System.out.println("Not a palindrome");
	}
}
