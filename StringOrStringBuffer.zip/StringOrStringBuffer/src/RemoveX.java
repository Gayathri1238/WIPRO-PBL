import java.util.*;
public class RemoveX {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		sc.close();
		String s1="";
		if(s.charAt(0)=='X'&& s.charAt(s.length()-1)=='X') {
			s1=s.replace(Character.toString(s.charAt(0)),"");
			s1=s.replace(Character.toString(s.charAt(s.length()-1)),"");
			System.out.println(s1);
		}
		else if(s.charAt(0)=='X') {
			s1=s.replace(Character.toString(s.charAt(0)),"");
			System.out.println(s1);
			}
		else if(s.charAt(s.length()-1)=='X') {
			s1=s.replace(Character.toString(s.charAt(s.length()-1)),"");
			System.out.println(s1);
		}
		
		else {
			System.out.println(s);
		}
	}
}
