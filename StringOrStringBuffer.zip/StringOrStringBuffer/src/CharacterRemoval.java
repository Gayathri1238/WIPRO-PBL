import java.util.*;
public class CharacterRemoval {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		sc.close();
		s=s.replace(Character.toString(s.charAt(0)), "");
		s=s.replace(Character.toString(s.charAt(s.length()-1)), "");
		System.out.println(s);
		
	}
}
