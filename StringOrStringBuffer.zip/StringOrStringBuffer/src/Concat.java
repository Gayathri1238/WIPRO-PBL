import java.util.*;
public class Concat {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		sc.close();
		String[] s1=s.split(",");
		s="";
		s=concatenation(s1[0].toLowerCase(),s1[1].toLowerCase());
		System.out.println(s);
	}
	public static String concatenation(String st1, String st2) 
	{
	        if (st1.length() != 0 && st2.length() != 0
	                && st1.charAt(st1.length() - 1) == st2.charAt(0))
	            return st1 + st2.substring(1);
	        return st1 + st2;
	}
}
