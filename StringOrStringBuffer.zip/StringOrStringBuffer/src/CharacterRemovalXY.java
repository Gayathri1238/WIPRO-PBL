import java.util.*;
public class CharacterRemovalXY {
    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc=new Scanner(System.in);
        String a=sc.nextLine();
        String b=sc.nextLine();
        sc.close();
        int ind=0,len=b.length(),len1=a.length();
        while(len1-ind>0)
        {
            ind=a.indexOf(b);
            if(ind==0 && (ind+len<len1))
                System.out.print(a.charAt(ind+len));
            if((ind==len1-len) && (ind!=0))
                System.out.print(a.charAt(ind-1));
            if((ind>0) && (ind+len<len1))
        System.out.print(a.charAt(ind-1)+""+a.charAt(ind+len));
            a=a.substring(ind+len);
            len1=a.length();
        }
    }
}