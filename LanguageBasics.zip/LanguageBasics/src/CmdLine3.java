public class CmdLine3 {
	public static void main(String[] args) {
		System.out.println("The sum of "+args[0]+"and "+args[1]+" is "+args[0]+args[1]);
	}
}
