public class FruitDemo {
	public static void main(String[] args) {
		Fruit f1=new Fruit();
		Fruit f2=new Apple();
		Fruit f3=new Orange();
		f1.eat();
		f2.eat();
		f3.eat();
	}
}
class Fruit{
	String name="Banana",taste="sweet";
	int size;
	public void eat() {
		System.out.println("Fruit name is: "+name+" and it's taste is: "+taste);
	}
}
class Apple extends Fruit{
	@Override
	public void eat() {
		System.out.println("Apple is fruit name and its taste is sweet");
	}
}
class Orange extends Fruit{
	@Override
	public void eat() {
		System.out.println("Orange is the fruit name and it's taste is sour");
	}
}
