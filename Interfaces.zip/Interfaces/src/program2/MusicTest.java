package program2;
import Music.Playable;
import Music.string.Veena;
import Music.wind.Saxophone;

public class MusicTest {
	public static void main(String[] args) {
		Playable veena = new Veena();
		veena.play();
		
		Playable saxophone = new Saxophone();
		saxophone.play();
	}
}

