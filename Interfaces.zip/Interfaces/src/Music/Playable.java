package Music;

public interface Playable {
	public void play();
}
