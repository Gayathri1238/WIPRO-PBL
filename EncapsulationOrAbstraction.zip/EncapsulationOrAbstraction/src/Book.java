import java.util.*;
public class Book {
	String name;
	Author author;
	double price;
	int qtyInStock;
	public void setName(String name) {
		this.name=name;
	}
	public void setAuthor(Author author) {
		this.author=author;
	}
	public void setPrice(double price) {
		this.price=price;
	}
	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock=qtyInStock;
	}
	public String getName() {
		return name;
	}
	public Author getAuthor() {
		return author;
	}
	public double getPrice() {
		return price;
	}
	public int getQtyInStock() {
		return qtyInStock;
	}
	public Book(String name,Author author,double price,int qtyInStock) {
		setName(name);
		setAuthor(author);
		setPrice(price);
		setQtyInStock(qtyInStock);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Author details");
		System.out.println("Enter Author Name:");
		String aname=sc.next();
		System.out.println("Enter Email of author:");
		String email=sc.next();
		System.out.println("Enter the gender of author");
		char ch=sc.next().charAt(0);
		Author a=new Author(aname,email,ch);
		System.out.println("Enter the name of the book:");
		String bname=sc.next();
		System.out.println("Enter the price of the book:");
		double p=sc.nextDouble();
		System.out.println("Enter the Stock available:");
		int s=sc.nextInt();
		sc.close();
		Book b=new Book(bname,a,p,s);
		System.out.println("Details are:");
		System.out.println("Book Name: "+b.getName()+"\nAuthor Details: \nAuthor name:"+a.getName()+"\nAuthor email: "+a.getEmail()+"\nAuthor Gender: "+a.getGender()+"\nBook Price: "+b.getPrice()
		+"\nBook Stock: "+b.getQtyInStock());
	}
}
