import java.util.*;
public class Search {
	public static void main(String[] main) {
		Scanner sc=new Scanner(System.in);
		int k=-1;
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		int ele=sc.nextInt();
		sc.close();
		for(int i=0;i<n;i++) {
			if(arr[i]==ele) {
				k=i;
			}
		}
		System.out.println(k);
	}
	
}
