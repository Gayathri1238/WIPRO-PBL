
import java.util.*;
public class SumAndAvg {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		int s=0;
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
			s+=arr[i];
		}
		sc.close();
		int avg=s/n;
		System.out.println("sum is: "+s+"\nAverage is: "+avg);
	}
}
