import java.util.*;
public class RemoveDuplicates {
	public static void main(String[] args) {
		LinkedHashSet<Integer> lh=new LinkedHashSet<>();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
			lh.add(arr[i]);
		}
		sc.close();
		Iterator itr=lh.iterator();
		while(itr.hasNext()) {
			System.out.print(itr.next()+" ");
		}
	}
}
