import java.util.*;
public class SmallestAndLargest {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		sc.close();
		Arrays.sort(arr);
		System.out.println("Smallest 2 numbers "+arr[0]+" "+arr[1]);
		System.out.println("Largest 2 numbers "+arr[n-2]+" "+arr[n-1]);
	}
}
