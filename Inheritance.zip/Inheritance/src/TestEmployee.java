import java.util.*;
public class TestEmployee {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Details:");
		System.out.println("Enter person name:");
		String name=sc.next();
		System.out.println("Enter person's Annual Salary:");
		double salary=sc.nextDouble();
		System.out.println("Enter person's joining year:");
		int year=sc.nextInt();
		System.out.println("Enter person's insurance:");
		String insNo=sc.next();
		sc.close();
		Employee e=new Employee(name,salary,year,insNo);
		System.out.println("Employee name: "+e.getName()+"\nEmployee salary: "+e.getAnnualSalary()+"\nEmployee joining year: "+e.getYear()+"\nEmployee insurance number: "+e.getInsurance());
		}
}