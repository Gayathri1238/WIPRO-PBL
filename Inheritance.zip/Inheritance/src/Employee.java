 class Employee extends Person {
	 double annualSalary;
	 int year;
	 String insurance;
	 public Employee(String name,double annualSalary,int year,String  insurance) {
		super(name);
		this.annualSalary=annualSalary;
		this.year=year;
		this.insurance=insurance;
	}
	 public String getName() {
		 return name;
	 }
	 public String getInsurance() {
		 return insurance;
	 }
	 public double getAnnualSalary() {
		 return annualSalary;
	 }
	 public int getYear() {
		 return year;
	 }
	
}
