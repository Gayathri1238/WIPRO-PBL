class CollegeStudent extends Student{
	String colgName;
	int year;
	public CollegeStudent(String name, String dob, int studentId,String colgName,int year) {
		super(name, dob, studentId);
		this.colgName=colgName;
		this.year=year;
	}
	public String getName() {
		return name;
	}
	public String getDOB() {
		return dob;
	}
	public int getStudentId() {
		return studentId;
	}
	public String getColgName() {
		return colgName;
	}
	public int getYear() {
		return year;
	}
}
