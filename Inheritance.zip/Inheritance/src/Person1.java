class Person1{
	String name,dob;
	public Person1(String name,String dob) {
		this.name=name;
		this.dob=dob;
	}
}