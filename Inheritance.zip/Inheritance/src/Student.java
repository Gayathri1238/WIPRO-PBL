class Student extends Person1{
	int studentId;
	public Student(String name,String dob,int studentId) {
		super(name,dob);
		this.studentId=studentId;
	}
}
