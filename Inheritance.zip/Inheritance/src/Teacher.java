class Teacher extends Person1{
	double salary;
	String subject;
	public Teacher(String name,String dob,double salary,String subject) {
		super(name,dob);
		this.salary=salary;
		this.subject=subject;
	}
	public String getName() {
		return name;
	}
	public String getDOB() {
		return dob;
	}
	public String getSubject() {
		return subject;
	}
	public double getSalary() {
		return salary;
	}
}
