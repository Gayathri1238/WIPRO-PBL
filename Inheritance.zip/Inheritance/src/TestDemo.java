import java.util.*;
public class TestDemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Choose: \n1.Teacher\n2.Student");
		int n=sc.nextInt();
		if(n==2) {
		System.out.println("Enter name:");
		String name=sc.next();
		System.out.println("Enter dob:");
		String dob=sc.next();
		System.out.println("Enter Student id: ");
		int id=sc.nextInt();
		System.out.println("Enter college name:");
		String clgname=sc.next();
		System.out.println("Enter year");
		int y=sc.nextInt();
		CollegeStudent st=new CollegeStudent(name,dob,id,clgname,y);
		System.out.println("Student details:");
		System.out.println("Name:"+st.getName()+"\nDOB:"+st.getDOB()+"\nStudent Id:"+st.getStudentId()
		+"\nCollegeName:"+st.getColgName()+"\nYear"+st.getYear());
		}
		else {
			System.out.println("Enter name:");
			String name=sc.next();
			System.out.println("Enter dob:");
			String dob=sc.next();
			System.out.println("Enter salary:");
			double salary=sc.nextDouble();
			System.out.println("Enter Subject: ");
			String sub=sc.next();
			sc.close();
			Teacher t=new Teacher(name,dob,salary,sub);
			System.out.println("Teacher Details:");
			System.out.println("Teacher name:"+t.getName()+"\nDOB:"+t.getDOB()+"\nTeacher salary:"+t.getSalary()+"\nSubject:"+t.getSubject());
		
	}
		}
	}
