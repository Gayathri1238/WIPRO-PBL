
public class StringCase {
	String datum;

    public StringCase(String datum) {
        this.datum = datum;
    }

    public String upperCase() {
        return datum.toUpperCase();
    }
}
