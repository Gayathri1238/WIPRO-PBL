import static org.junit.Assert.*;

import org.junit.Test;
import java.util.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.Parameters;
import org.junit.runner.RunWith;

@RunWith(Parameterized.class)
public class StringCaseTest {
    private String datum;
    private String expected;

    public StringCaseTest(String datum, String expected) {
        this.datum = datum;
        this.expected = expected;
    }


    @Parameters
    public static Collection<Object[]> generateData() {
        Object[][] data = new Object[][] {
            {"Sowji", "SOWJI"},
            {"sowji", "SOWJI"},
            {"SOwjI", "SOWJI"},
            {"SowjI", "SOWJI"}
        };

        return Arrays.asList(data);
    }

    @Test
    
    public void testUpperCase() {
        StringCase s = new StringCase(this.datum);
        String actualResult = s.upperCase();
        assertEquals(actualResult, this.expected);
    }

}