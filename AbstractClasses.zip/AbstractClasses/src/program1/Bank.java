package program1;

public abstract class Bank {
	public abstract double getSavingInterestRate();
	
	public abstract double getFixedInterestRate();
}
