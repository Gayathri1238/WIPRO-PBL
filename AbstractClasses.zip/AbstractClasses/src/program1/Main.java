package program1;

public class Main {
	public static void main(String[] args) {
		ICICI iciciBank = new ICICI();
		KotM kotMBank = new KotM();

		System.out.println(iciciBank.getSavingInterestRate());
		System.out.println(iciciBank.getFixedInterestRate());
		System.out.println(kotMBank.getSavingInterestRate());
		System.out.println(kotMBank.getFixedInterestRate());
		
		Bank b1 = new ICICI();
		Bank b2 = new KotM();
		
		System.out.println(b1.getSavingInterestRate());
		System.out.println(b1.getFixedInterestRate());
		System.out.println(b2.getSavingInterestRate());
		System.out.println(b2.getFixedInterestRate());
	}

}
