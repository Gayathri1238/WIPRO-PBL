package program2;

public abstract class Compartment {
	public abstract void notice();
}
