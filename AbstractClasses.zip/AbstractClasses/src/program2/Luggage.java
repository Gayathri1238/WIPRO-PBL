package program2;
public class Luggage extends Compartment {
	public void notice() {
		System.out.println("Notice: This is Luggage Compartment");
	}

}
