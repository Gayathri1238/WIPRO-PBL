package program2;

public class Ladies extends Compartment {
		public void notice() {
			System.out.println("Notice: This is Ladies Compartment");
		}

	}

