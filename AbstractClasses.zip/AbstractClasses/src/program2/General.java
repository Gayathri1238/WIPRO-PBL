package program2;

public class General extends Compartment {
	public void notice() {
		System.out.println("Notice: This is General");
	}

}
