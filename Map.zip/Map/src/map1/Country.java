package map1;
import java.util.*;

public class Country {
	private HashMap<String, String> M1;
	
	public Country() {
		M1 = new HashMap<String, String>();
	}
	
	public HashMap<String, String> saveCountryCapital(String CountryName, String capital) {
		M1.put(CountryName, capital);
		return M1;
	}
	
	public String getCapital(String CountryName) {
		return M1.get(CountryName);
	}
	
	public String getCountry(String capitalName) {
		for(Map.Entry<String,String> m: M1.entrySet()) {	
			if (m.getValue().equals(capitalName))
				return m.getKey();
		}
		
		return null;
	}
	
	public HashMap<String, String> swapKeyValue() {
		HashMap<String, String> M2 = new HashMap<String, String>();
		
		for(Map.Entry<String,String>me:M1.entrySet()) {
			M2.put(me.getValue(), me.getKey());
		}
		
		return M2;
	}
	
	public ArrayList<String> toArrayList() {
		ArrayList<String> list = new ArrayList<>();
		for(Map.Entry<String,String> me:M1.entrySet()) {
			list.add(me.getKey());
		}
		
		return list;
	}
}