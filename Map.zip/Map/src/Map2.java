import java.util.*;
public class Map2 {
	public static void main(String[] args) {
		Map<String,String> M1 = new HashMap<String,String>();
		
		M1.put("India","Delhi");
		M1.put("Pakistan","Istanbul");
		M1.put("USA","Washington");
		
		for(Map.Entry<String,String> me:M1.entrySet()) {
			if (me.getKey().equals("Japan")) {
				System.out.println("Key Japan exists");
				break;
			}
		}
		
		
		for(Map.Entry<String, String> me:M1.entrySet()) {
			
			if (me.getValue().equals("Delhi")) {
				System.out.println("Value Delhi exists");
				break;
			}
		}
		
		
		for(Map.Entry<String,String> me:M1.entrySet()) {
			System.out.println(me);
			System.out.println("Key: " + me.getKey() + ", Value: " + me.getValue());
		}
		
		
	}
}
		