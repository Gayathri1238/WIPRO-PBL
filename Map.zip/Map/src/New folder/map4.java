package map4;
public class map4 {

	public static void main(String[] args) {
		ContactList contactsList = new ContactList();
		
		contactsList.addContact("Sowji", 258941);
		contactsList.addContact("Latha", 285621);
		contactsList.addContact("Akhil", 254512);
				
		System.out.println("sowji: " + contactsList.doesContactNameExist("Akhil"));
		System.out.println("9799988788: " + contactsList.doesContactNumberExist(258941));
		
		System.out.println();
		contactsList.listAllContacts();
	}

}