package palindrome;
import static org.junit.Assert.*;

import org.junit.Test;

public class PalindromeTest {
    Palindrome p = new Palindrome();

    @Test
    public void testPalindromeCheck() {
        assertEquals("Result:", true, p.palindromeCheck("madam"));
        assertEquals("Result:", true, p.palindromeCheck("mom"));
        assertEquals("Result:", true, p.palindromeCheck("dad"));
        assertEquals("Result:", true, p.palindromeCheck("malayalam"));
        assertEquals("Result:", false, p.palindromeCheck("kerala"));
        assertTrue("Result: ", p.palindromeCheck("madam"));
        assertTrue("Result: ", p.palindromeCheck("mom"));
        assertTrue("Result: ", p.palindromeCheck("dad"));
        assertTrue("Result: ", p.palindromeCheck("malayalam"));
        assertFalse("Result: ", p.palindromeCheck("kerala"));
        assertFalse("Result: ", p.palindromeCheck("india"));
    }

}
