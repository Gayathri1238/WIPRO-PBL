import java.util.*;
public class Wrapper3 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        sc.close();
        String output = String.format("%8s", Integer.toBinaryString(num)).replace(' ', '0');
        System.out.println(output);
    }
}

