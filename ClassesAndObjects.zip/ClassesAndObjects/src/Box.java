import java.util.*;
public class Box {
	private int width,height,depth;
	public Box(int width,int height,int depth) {
		this.width=width;
		this.height=height;
		this.depth=depth;
	}
	public double calculateVolume() {
		double vol=width*height*depth;
		return vol;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the dimesions:");
		int w=sc.nextInt();
		int h=sc.nextInt();
		int d=sc.nextInt();
		sc.close();
		Box b=new Box(w,h,d);
		System.out.println("Volume is: "+b.calculateVolume());
	}
}
