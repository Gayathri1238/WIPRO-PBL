import java.util.*;
public class Calculator {
	public static int powerInt(int num1,int num2) {
		return (int)(Math.pow(num1,num2));
	}
	public static double powerDouble(double num1,double num2) {
		return Math.pow(num1, num2);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Integer numbers:");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		System.out.println("Power of Integer numbers is: "+powerInt(n1,n2));
		System.out.println("Enter the double type numbers:");
		double d1=sc.nextDouble();
		double d2=sc.nextDouble();
		sc.close();
		System.out.println("Power of double numbers is:"+powerDouble(d1,d2));
	}
}
