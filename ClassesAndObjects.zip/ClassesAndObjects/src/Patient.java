import java.util.Scanner;
public class Patient {
	String patientName;
	double height,weight;
	public Patient(double height,double weight) {
		this.height=height;
		this.weight=weight;
	}
	double calculateBMI() {
		double bmi=(weight)/(Math.pow(height,2));
		return bmi;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter patient name:");
		 String name=sc.next();
		System.out.println("Enter weight in kg's:");
		double w=sc.nextDouble();
		System.out.println("Enter height in metres:");
		double h=sc.nextDouble();
		sc.close();
		Patient p=new Patient(h,w);
		System.out.println("Patient Details");
		System.out.println("Patient Name: "+name+"\n"+"BMI is: "+p.calculateBMI());
	}
	
}
